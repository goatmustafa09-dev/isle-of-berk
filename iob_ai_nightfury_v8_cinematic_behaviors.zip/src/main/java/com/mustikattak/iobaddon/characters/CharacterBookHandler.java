package com.mustikattak.iobaddon.characters;

import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

public class CharacterBookHandler {

    private static final String BOOK_FLAG = "iob_char_book_given";

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer)) return;
        ServerPlayer player = (ServerPlayer) event.getPlayer();
        if (player.getPersistentData().getBoolean(BOOK_FLAG)) return;
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        player.getInventory().add(book);
        player.getPersistentData().putBoolean(BOOK_FLAG, true);
        player.sendSystemMessage(Component.literal("Karakter Seçimi kitabı verildi — chatte çıkan [Seç] butonlarına tıklayın."));
        CharacterCommandHelper.sendSelectionButtons(player);
    }
}
