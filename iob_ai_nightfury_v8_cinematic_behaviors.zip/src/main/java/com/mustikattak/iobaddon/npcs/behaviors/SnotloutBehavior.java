package com.mustikattak.iobaddon.npcs.behaviors;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;

public class SnotloutBehavior extends Goal {
    private final Mob npc;
    public SnotloutBehavior(Mob npc) { this.npc = npc; this.setFlags(EnumSet.of(Flag.MOVE)); }
    @Override public boolean canUse() { return true; }
    @Override public void tick() { /* boasting / taunting placeholder */ }
}
