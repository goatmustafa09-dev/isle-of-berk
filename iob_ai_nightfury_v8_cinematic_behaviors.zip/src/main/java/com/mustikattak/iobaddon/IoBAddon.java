package com.mustikattak.iobaddon;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;

@Mod("iob_ai_addon")
public class IoBAddon {
    public IoBAddon() {
        MinecraftForge.EVENT_BUS.register(new com.mustikattak.iobaddon.characters.CharacterBookHandler());
        MinecraftForge.EVENT_BUS.register(new com.mustikattak.iobaddon.npcs.NPCSpawner());
        MinecraftForge.EVENT_BUS.register(new com.mustikattak.iobaddon.ai.EmotionManager());
        System.out.println("[Isle of Berk AI Addon v8.0] Loaded cinematic behaviors."); 
    }
}
