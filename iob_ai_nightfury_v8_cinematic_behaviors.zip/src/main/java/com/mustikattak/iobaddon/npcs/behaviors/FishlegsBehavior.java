package com.mustikattak.iobaddon.npcs.behaviors;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;

public class FishlegsBehavior extends Goal {
    private final Mob npc;
    public FishlegsBehavior(Mob npc) { this.npc = npc; this.setFlags(EnumSet.of(Flag.LOOK)); }
    @Override public boolean canUse() { return true; }
    @Override public void tick() { /* analyze nearby dragons placeholder */ }
}
