package com.mustikattak.iobaddon.npcs;

import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.core.BlockPos;
import com.mustikattak.iobaddon.characters.CharacterManager;

public class NPCSpawner {

    @SubscribeEvent
    public void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer)) return;
        ServerPlayer player = (ServerPlayer) event.getPlayer();
        CharacterManager.getCharacter(player).ifPresent(id -> spawnFor(player, id));
    }

    private void spawnFor(ServerPlayer player, String id) {
        // spawn logic: create movie-character NPCs as Villager placeholders with personalities
        var world = player.level;
        BlockPos base = player.blockPosition();
        // For Hiccup selection spawn Astrid, Fishlegs, Twins, Snotlout near player
        if (id.equals("hiccup")) {
            spawnVillager(world, base.offset(2,0,1), "astrid"); 
            spawnVillager(world, base.offset(1,0,2), "fishlegs"); 
            spawnVillager(world, base.offset(-1,0,2), "tuffnut"); 
            spawnVillager(world, base.offset(-2,0,1), "ruffnut"); 
            spawnVillager(world, base.offset(0,0,-2), "snotlout"); 
        } else if (id.equals("astrid")) {
            spawnVillager(world, base.offset(2,0,1), "hiccup"); 
            spawnVillager(world, base.offset(1,0,2), "fishlegs"); 
        } else if (id.equals("fishlegs")) {
            spawnVillager(world, base.offset(1,0,1), "hiccup"); 
            spawnVillager(world, base.offset(1,0,2), "astrid"); 
        } else if (id.equals("tuffnut") || id.equals("ruffnut")) {
            spawnVillager(world, base.offset(1,0,1), "twin_other"); 
        } else if (id.equals("snotlout")) {
            spawnVillager(world, base.offset(1,0,1), "hiccup"); 
        }
    }

    private void spawnVillager(net.minecraft.world.level.Level world, BlockPos pos, String role) {
        Villager v = EntityType.VILLAGER.create(world);
        if (v == null) return;
        v.moveTo(pos.getX()+0.5, pos.getY(), pos.getZ()+0.5, 0, 0);
        world.addFreshEntity(v);
        if (!world.isClientSide && v instanceof Mob) {
            // attach role as persistent data for behavior lookup
            v.getPersistentData().putString("iob_role", role);
        }
    }
}
