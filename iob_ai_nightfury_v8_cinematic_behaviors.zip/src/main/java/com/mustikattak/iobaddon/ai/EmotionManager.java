package com.mustikattak.iobaddon.ai;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.network.chat.Component;

public class EmotionManager {

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        // placeholder: in a full mod, iterate entities with persistent data and update emotions
    }

    public static void broadcastEmotion(ServerPlayer player, String who, String msg) {
        if (player == null) return;
        player.sendSystemMessage(Component.literal("[" + who + "] " + msg));
    }
}
