package com.mustikattak.iobaddon.characters;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;

public class CharacterCommandHelper {
    public static void sendSelectionButtons(ServerPlayer player) {
        send(player, "Hıçkıdık", "hiccup");
        send(player, "Astrid", "astrid");
        send(player, "Balıkayak", "fishlegs");
        send(player, "Sertceviz", "tuffnut");
        send(player, "Tersceviz", "ruffnut");
        send(player, "Sümüklü", "snotlout");
    }

    private static void send(ServerPlayer player, String label, String id) {
        Component comp = Component.literal("[Seç: " + label + "] ")
            .setStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/iob_select " + id)));
        player.sendSystemMessage(comp);
    }
}
