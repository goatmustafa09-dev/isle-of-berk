package com.mustikattak.iobaddon.npcs.behaviors;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;

public class HiccupBehavior extends Goal {
    private final Mob npc;
    public HiccupBehavior(Mob npc) {
        this.npc = npc;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }
    @Override
    public boolean canUse() { return true; }
    @Override
    public void tick() {
        // Hiccup-style thoughtful behavior placeholder
    }
}
