package com.mustikattak.iobaddon.npcs;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

public class DialogueManager {
    public static void say(ServerPlayer player, String who, String line) {
        if (player == null) return;
        player.sendSystemMessage(Component.literal("[" + who + "] " + line));
    }
}
