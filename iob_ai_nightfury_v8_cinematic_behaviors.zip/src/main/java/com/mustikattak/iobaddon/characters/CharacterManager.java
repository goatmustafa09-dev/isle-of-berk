package com.mustikattak.iobaddon.characters;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Optional;
import net.minecraft.server.level.ServerPlayer;

public class CharacterManager {
    private static final Map<String, String> chosen = new ConcurrentHashMap<>(); // playerUUID -> charId

    public static boolean isTaken(String charId) {
        return chosen.containsValue(charId);
    }

    public static void setCharacter(ServerPlayer player, String charId) {
        chosen.put(player.getStringUUID(), charId);
    }

    public static Optional<String> getCharacter(ServerPlayer player) {
        return Optional.ofNullable(chosen.get(player.getStringUUID()));
    }
}
