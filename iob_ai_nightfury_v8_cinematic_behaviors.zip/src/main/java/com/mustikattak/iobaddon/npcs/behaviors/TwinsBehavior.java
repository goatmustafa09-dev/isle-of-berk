package com.mustikattak.iobaddon.npcs.behaviors;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import java.util.EnumSet;

public class TwinsBehavior extends Goal {
    private final Mob npc;
    public TwinsBehavior(Mob npc) { this.npc = npc; this.setFlags(EnumSet.of(Flag.MOVE)); }
    @Override public boolean canUse() { return true; }
    @Override public void tick() { /* argue with nearby twin placeholder */ }
}
