Isle of Berk AI Addon v8.0 - Cinematic Behaviors


This package contains the v8.0 source skeleton for the Cinematic Behaviors update.

It includes behavior classes for each film character so NPCs act like the movie characters.


How to build:
1. Download Forge MDK 1.18.2 and extract.
2. Merge this src/ into the MDK's src/ (or replace src/)
3. Run ./gradlew build in the MDK root.
4. Copy build/libs/*.jar into your .minecraft/mods/ with Isle of Berk installed.

Notes:
- This is a source skeleton with concrete behavior code stubs. You will need Forge mappings and MDK to build.
- For building online, use Replit, Gitpod, or GitHub Actions (instructions below).
