Recommended online builders to create the Forge .jar from this source:


1) Replit (https://replit.com)
   - Create a new 'Java' or 'Bash' Replit.
   - Upload Forge MDK (1.18.2) files and this source into the workspace.
   - Use the Replit terminal to run: ./gradlew build
   - After build, download build/libs/*.jar

2) Gitpod (https://gitpod.io)
   - Create a GitHub repo containing Forge MDK + this source.
   - Open the repo in Gitpod and run ./gradlew build

3) GitHub Actions
   - Create a workflow that checks out the repo and runs ./gradlew build on ubuntu-latest.
   - The artifact (jar) can be downloaded from the Actions page.

Notes:
- Online builders require a user account and may need increased storage/time for Forge downloads.
- Always include the official Forge MDK (not redistributed) when setting up the build.
